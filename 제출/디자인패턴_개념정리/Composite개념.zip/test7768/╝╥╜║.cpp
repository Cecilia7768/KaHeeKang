﻿#include<iostream>
#include<vector>
using namespace std;

class Filesystem
{
	string name;
public:
	int getsize();
	void remove();
	string name() { return name; }
};

class File : Filesystem
{
private:
	string name;
	int size;
public:
	File(string _name, int size) { name = _name; }
	int getsize()
	{
		cout << name << "+ 파일크기 : " << size;
		return size;
	}
	void remove() 
	{
		delete this;
		cout << name << "파일 삭제"; 
	}
};

class Folder :Filesystem
{
private:
	string name;
	vector<Filesystem> includeds;
public:
	Folder(string _name) { name = _name; }
	void add(Folder forder) { includeds.push_back(forder); }
	int getsize()
	{
		int total = 0;
		total = includeds.size();
		return total;
	}
	void remove() {
		for (int i = 0; i < includeds.size(); i++)
		{
			if (includeds.at(i).name() == name)
				includeds.erase(includeds.begin()+i);
		}
		cout << name << " 폴더 삭제\n - - - - -";
	}

};

//class CompositePattern
//{
//public:
//	static void main()
//	{
//		Folder* schoolForder = new Folder("학교");
//		Folder* grade1Folder = new Folder("1학년");
//		Folder* grade2Folder = new Folder("2학년");
//
//		schoolForder.add(*grade1Folder);
//		schoolForder.add(*grade2Folder);
//
//		File *photo = new File("학생사진", 256);
//		grade1Folde.add(photo);
//
//		cout << schoolForder.getsize();
//	}
//}