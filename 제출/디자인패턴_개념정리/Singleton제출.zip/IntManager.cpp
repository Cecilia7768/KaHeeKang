#include "IntManager.h"

IntManager* IntManager::m_pthis = NULL;

IntManager::IntManager()
{
	
}

void IntManager::Insert()
{
	m_vecIntList.push_back(new Int);
}

void IntManager::ShowList()
{
	for (int i = 0; i < m_vecIntList.size(); i++)
	{
		m_vecIntList[i]->Show();
	}
}

IntManager::~IntManager()
{
}