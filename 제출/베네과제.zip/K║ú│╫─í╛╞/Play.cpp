#include"Play.h"

Play::Play()
{
}

void Play::Print_Main()
{
	int choice;
	while (1)
	{
		For_Resetting();
		m_DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
		m_DrawManager.DrawMidText("�� �� �� �� ġ �� �� ��", WIDTH, HEIGHT * 0.3);
		m_DrawManager.DrawMidText("1. Game Start", WIDTH, HEIGHT * 0.4);
		m_DrawManager.DrawMidText("2. Rank", WIDTH, HEIGHT * 0.5);
		m_DrawManager.DrawMidText("3. Exit", WIDTH, HEIGHT * 0.58);
		DrawBaseInterface();
		switch (m_DrawManager.MenuSelectCursor(3, 3, WIDTH * 0.38, HEIGHT * 0.4))
		{
		case 1:
			For_resetting();
			Main_Before_Play(); //����,���丮����,�̸��Է�
			break;
		case 2:
			m_rank.Print_Rankers();
			break;
		case 3:
			return;
		}
	}
}


void Play::Main_Before_Play()
{
	char buf[256];
	char ch;
	int line = 1;
	ifstream Load;
	string tmp;
	string storyline[STORYLINE_MAX];
	
	sprintf(buf, "����ġ��_���丮.txt");
	Load.open(buf);
	system("cls");
	DrawBaseInterface();
	m_DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
	while (!Load.eof())
	{		
		DrawSkipBox();
		if (Check_Skip == true)
			break;
		for (int i = 0; i < STORYLINE_MAX; i++)
		{	
			if (kbhit())  
			{
				ch = getch();
				if (ch == 's')    
				{
					Check_Skip = true;
					break;
				}
			}
			Sleep(1000);	
			getline(Load, tmp);
			storyline[i] = tmp;
			if (i < 10) //ù��° ���
				m_DrawManager.DrawMidText(storyline[i], WIDTH, HEIGHT * 0.3 + i);
			else if (NULL == i% STORYLINE_SIZE || i ==STORYLINE_MAX) 
				Check_Storyline_Max = true;
			if (Check_Storyline_Max == true) 
			{	
				for (int j = 0; j< STORYLINE_SIZE; j++)
				{	
					m_DrawManager.DrawMidText("                                                  ", WIDTH, HEIGHT * 0.3 + j);
					m_DrawManager.DrawMidText(storyline[j+line], WIDTH, HEIGHT * 0.3 + j);
				}				
				line++;
			}	
		}
	}		
	Input_Name();
	Playing_Game();
}

void Play::DrawSkipBox()
{
	m_DrawManager.BoxDraw(WIDTH * 1.0, HEIGHT * 0.7, WIDTH / 3, HEIGHT / 6);
	SKY_BLUE
		m_DrawManager.DrawMidText("Skip : S", WIDTH, HEIGHT * 0.75);
	ORIGINAL
}

void Play::Input_Name()
{
	char Name[NAMESIZE] = {0};
	char ch;
	bool check_finished_naming = false; //���̹� �������� üũ
	bool check_error_naming = false;
	int namecheck = 0;
	string NameSet;
	while (!check_finished_naming)
	{
		system("cls");
		m_DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
		SKY_BLUE
			m_DrawManager.DrawMidText("�̸� �Է�", WIDTH, HEIGHT * 0.75 - 5);
		m_DrawManager.BoxDraw(WIDTH * 1.0, HEIGHT * 0.7, WIDTH / 3, HEIGHT / 6);
		m_DrawManager.gotoxy(WIDTH, HEIGHT * 0.75);
		ORIGINAL
			while (1)
			{
				if (check_error_naming == true)
				{
					for (int i = 0; i < NAMESIZE; i++)
					{
						Name[i] = NULL;
					}
					namecheck = 0;
					check_error_naming = false;
				}
				ch = getch();
				if (Name[NAMESIZE - 1] != NULL)
				{
					m_DrawManager.gotoxy(WIDTH + 5, HEIGHT * 0.6);
					SKY_BLUE
						cout << "10���� �ʰ�!";
					ORIGINAL
						check_error_naming = true;
					if(getch())
						break;
				}

				else if (('a' <= ch && ch <= 'z') || ('A' <= ch && ch <= 'Z'))
				{
					Name[namecheck] = ch;
					NameSet += Name[namecheck];
					namecheck++;
				}
				else if (ch == ENTER)
				{
					if (ch == NULL || namecheck == 0 || NameSet == "")
						continue;
					else
					{
						m_iName = NameSet;
						check_finished_naming = true; //�̸������� ������ �Լ��� �����
						break;
					}
				}
				else if (ch == BACK_SPACE || ch == SPACE) 
				{
					for (int i = 0; i < NAMESIZE; i++)
					{
						Name[i] = NULL;
					}				
					NameSet = "";
					namecheck = 0;
					m_DrawManager.EraseWord(NAMESIZE, 61, 26);//�ܾ� �Է�â û��			
				}
				m_DrawManager.DrawMidText(NameSet, WIDTH, HEIGHT * 0.75);
			}
	}
}

void Play::Playing_Game()
{
	int Select = 0;

	Load_Word();	// �ܾ� �ҷ�����

	while (1)
	{
		system("cls");
		m_DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
		DrawBaseInterface();
		m_DrawManager.DrawMidText("��  ", WIDTH, HEIGHT * 0.4);
		cout << stage_count << " Stage  ��";
		getch();
		for (int i = 0; i < w.size(); i++)
		{
			w[i]->check_remain = TRUE;
		}
		system("cls");
		if (m_bNext_Stage)
		{
			m_iScore = 0;
			m_bNext_Stage = false;
			tmpw_list.clear();
		}		
		///////////////// �׽��� //////////

		SKY_BLUE
			m_DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
		DrawBaseInterface();
		m_DrawManager.BoxDraw(WIDTH * 1.0, HEIGHT * 0.7, WIDTH / 3, HEIGHT / 6);
		m_DrawManager.gotoxy(WIDTH, HEIGHT * 0.75);
		ORIGINAL
			while (!Check_Gameover() && !m_bNext_Stage)
			{
				Drop_Word();
			}	
		if (Check_Gameover())
		{
			Save_Rank();			
			break;
		}

	}
}

void Play::Save_Rank()
{
	ofstream Save;

	Save.open("Rank.txt", ios::app);

	if (Save.is_open())
	{
		Save << m_iName;
		Save << " ";
		Save << stage_count;
		Save << " ";
		Save << m_iTotal_score;
		Save << endl;
	}
	Save.close();
}

void Play::For_resetting()
{
	w.clear();
	tmpw_list.clear();
	m_iLife = MAX_LIFE;
	m_iScore = 0;
	Check_Skip = false; //��ŵ���� üũ
	Check_Storyline_Max = false; //���丮���� ���о����� üũ
	m_iTotal_score = 0;	
	stage_count = 1;
	m_iScore = 0;
	m_bNext_Stage = false; //���� �������� ������ �´���
}

Play::~Play()
{
}