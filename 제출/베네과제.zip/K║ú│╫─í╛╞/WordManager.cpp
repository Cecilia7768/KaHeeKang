#include"WordManager.h"

WordManager::WordManager()
{
	m_iMaking_color_of_word = stage_count* PROBABILITY_COLOR; //�����ִ� �ܾ ���� Ȯ��
	m_iScore = 0;
}

int WordManager::Case_by_Color()
{
	int rand_color = rand() % m_iMaking_color_of_word;
	if (rand_color == 1)
		return TRUE;
	else
		return FALSE;		
}


void WordManager::Load_Word()
{
	ifstream Load;
	int tmp_x;
	string tmpname;

	Load.open("Word.txt");
	if (!Load)
	{
		system("cls");
		cout << "�ش� ������ �����ϴ�" << endl;
		getch();
	}
	else
	{		
		while (!Load.eof())
		{
			WORD_M* tmpword_list = new WORD_M; //���߿� ���� û���ϱ�
			tmp_x = rand() % WORD_X+2;
			tmpword_list->x = tmp_x;
			tmpword_list->y = 3;
			tmpword_list->check_remain = TRUE;
			tmpword_list->check_appear = FALSE;
			Load >> tmpname;
			tmpword_list->name = tmpname;
			w.push_back(tmpword_list);
		}
	}
	Load.close();

}
void WordManager::Drop_Word()
{
	int fir_time, sec_time;
	int i;
	int y = 0;
	int onscreen_th = 0;
	string tmpw;
	fir_time = clock();
	input_w = "";

	while (!Check_Gameover() && !m_bNext_Stage) //���ӿ����� �ǰų� �������� Ŭ��� ������ ��� ����
	{
		i = rand() % WORD_LIST;
		sec_time = clock();
		m_DrawManager.DrawMidText(input_w, WIDTH, HEIGHT * 0.75); //63.26
		if (sec_time - fir_time >= SPEED / stage_count) //���������� ���������� �ܾ�ӵ� ������
		{
			if (w[i]->check_remain == TRUE) //�ܾ ���������ٸ�
			{
				tmpw = w[i]->name;
				m_DrawManager.gotoxy(w[i]->x, w[i]->y);
				if (Case_by_Color() == TRUE) 
				{
					w[i]->color = 1;
					w[i]->score = 50;
					RED
						cout << tmpw;
				}
				else
				{
					w[i]->color = 0;
					w[i]->score = 20;
					SKY_BLUE
						cout << tmpw;
				}
				w[i]->check_appear = TRUE; //�ܾ� ��� �Ϸ� üũ
				w[i]->check_remain = FALSE; //��µ� �ܾ�� ������
				tmpw_list.push_back(w.at(i)); //���Դ� �ܾ� ����
			}
			if (!tmpw_list.empty())
			{
				Sleep(SPEED / stage_count);
				for (int y = 0; y < tmpw_list.size(); y++)
				{
					if (tmpw_list[y]->check_appear == TRUE)
					{
						m_DrawManager.EraseWord(tmpw_list[y]->name.length(), tmpw_list[y]->x, tmpw_list[y]->y);
						tmpw_list[y]->y += 2;
						m_DrawManager.gotoxy(tmpw_list[y]->x, tmpw_list[y]->y);
						if (tmpw_list[y]->color == 1)
							RED
						else
							SKY_BLUE
							cout << tmpw_list[y]->name;
						if (tmpw_list[y]->y >= HEIGHT)
						{
							m_DrawManager.EraseWord(tmpw_list[y]->name.length(), tmpw_list[y]->x, tmpw_list[y]->y);
							tmpw_list[y]->check_appear = FALSE;
							m_iLife--;
							DrawBaseInterface();
							if (Check_Gameover() == true) //���ӿ����Ǹ� ��������
								return ;
						}
						SKY_BLUE
							m_DrawManager.BoxDraw(WIDTH * 1.0, HEIGHT * 0.7, WIDTH / 3, HEIGHT / 6);
						ORIGINAL
							m_DrawManager.gotoxy(WIDTH, HEIGHT * 0.75);
						if (kbhit())
						{
							Input_Compare_Word();	
							if (m_bNext_Stage)
								break;
						}
					}
				}
				if (m_bNext_Stage)//Ŭ�����ϸ� �ƹ��� ����
				{
					stage_count++;
					return;
				}
			}
		}
	}
}
bool WordManager::Check_Clear_Stage()
{
	if (m_iTotal_score  >= (100 * stage_count))
	{
		m_bNext_Stage = true;
		for (int i = 0; i < w.size(); i++) //y�� �ʱ�ȭ
		{
			w[i]->y = 3;
		}
		return true;
	}
	
	else
		return false;
}


void WordManager::Input_Compare_Word()
{
	char tmplist[NAMESIZE] = { 0 };
	char compare[NAMESIZE] = { 0 };
	string compare_w;
	string check;
	char ch;
	int comparecount = 0;
	int result;
	bool check_done = false;

		m_DrawManager.gotoxy(WIDTH, HEIGHT * 0.75);
		ch = getch();
		if (ch == BACK_SPACE) //�ƿ� ����������
		{
			cin.clear();//���� �ʱ�ȭ
			for (int i = 0; i < NAMESIZE; i++)
			{
				tmplist[i] = { 0 };
			}
			comparecount = 0;
			input_w = "";
			m_DrawManager.EraseWord(NAMESIZE, 63, 26);//�ܾ� �Է�â û��
			return;
		}
		else if (('a' <= ch && ch <= 'z') || ('A' <= ch && ch <= 'Z'))
		{
			tmplist[comparecount] = ch;
			input_w += tmplist[comparecount];
			comparecount++;	
			m_DrawManager.DrawMidText(input_w, WIDTH, HEIGHT * 0.75); //63.26
		}
		else if (ch == ENTER)
		{
			if (Check_Gameover() == true) //���ӿ����Ǹ� ��������
				return;
			comparecount = 0;
			for (int i = 0; i < tmpw_list.size(); i++)
			{
				if (tmpw_list[i]->check_appear)
				{
					compare_w = tmpw_list[i]->name;
					check = input_w;
					result = compare_w.compare(check);
					if (result == 0)
					{
						m_iTotal_score += tmpw_list[i]->score;
						DrawBaseInterface();
						m_DrawManager.EraseWord(tmpw_list[i]->name.length(), tmpw_list[i]->x, tmpw_list[i]->y);
						m_DrawManager.EraseWord(check.length() + 2, 63, 26);//�ܾ� �Է�â û��
						tmpw_list.erase(tmpw_list.begin() + i);
						check_done = true;
						input_w.clear();
						if (Check_Clear_Stage())//Ŭ�����ϸ� �ƹ��� ����
							return;
						break;
					}
					else if (input_w == "")
						return;
					else if (i == tmpw_list.size() - 1)//Ʋ�� �Է��� �ϸ� ����������
					{
						m_iLife--;
						DrawBaseInterface();
					}
				}
			}

		if (check_done)
			return;
	}
}

WordManager::~WordManager()
{
}