#include "Rank.h"

Rank::Rank()
{
	check_first_Loading = true;
}

void Rank::Print_Rankers()
{
	char ch;
	char tmp[256];
	SKY_BLUE
	m_DrawManager.BoxDraw(0, 0, WIDTH, HEIGHT);
	m_DrawManager.BoxDraw(WIDTH * 1.0, HEIGHT * 0.1, WIDTH / 3, HEIGHT *0.15);
	SKY_BLUE
	m_DrawManager.DrawMidText("Ranking", WIDTH, HEIGHT * 0.15);
	for (int i = 0; i < WIDTH*2 -2; i++)
	{
		m_DrawManager.gotoxy(1+i, HEIGHT * 0.25);
		SKY_BLUE
			cout << "=";
	}	
	if (check_first_Loading == true)
	{
		Load_Rankers();
		check_first_Loading = false;
	}
	while (1)
	{
		if (!rankers_list.empty())
		{
			Cleanup_RankList();
			m_DrawManager.DrawMidText("Name                    Score                    Stage", WIDTH, HEIGHT * 0.1 + 7);

			for (int i = 0; i < rankers_list.size(); i++)
			{
				sprintf(tmp, "%d", rankers_list[i]->m_iRank_Score);
				m_DrawManager.DrawMidText(tmp, WIDTH - 1, HEIGHT * 0.1 + 8 + (i * 2));
				sprintf(tmp, "%d", rankers_list[i]->m_iRank_Stage);
				m_DrawManager.DrawMidText(tmp, WIDTH * 1.3 + 3, HEIGHT * 0.1 + 8 + (i * 2));
				m_DrawManager.DrawMidText(rankers_list[i]->m_sRank_name, WIDTH * 0.6, HEIGHT * 0.1 + 8 + (i * 2));
			}
			break;
		}
	}
	ch = getch();
}

void Rank::Cleanup_RankList()
{

	for (int i = 0; i < rankers_list.size()-1; i++)
	{
		for (int j = i+1; j < rankers_list.size(); j++)
		{
			if (rankers_list[j]->m_iRank_Score > rankers_list[i]->m_iRank_Score)
			{
				swap(rankers_list[j], rankers_list[i]); //�±�ȯ��
			}
			else if (rankers_list[j]->m_iRank_Stage == rankers_list[i]->m_iRank_Stage)
			{
				if (rankers_list[j]->m_iRank_Score > rankers_list[i]->m_iRank_Score)
				{
					swap(rankers_list[j], rankers_list[i]); 
				}
			}
		}
	}	
}

void Rank::Load_Rankers()
{
	ifstream Load;

	Load.open("Rank.txt");
	if (!Load)
	{
		system("cls");
		cout << "�ش� ������ �����ϴ�" << endl;
	}
	else
	{
		while (!Load.eof())
		{
			Rankers* tmpranks = new Rankers;
			Load >> tmpranks->m_sRank_name;
			Load >> tmpranks->m_iRank_Stage;
			if (tmpranks->m_iRank_Stage <= 0)
				break;
			Load >> tmpranks->m_iRank_Score;
			rankers_list.push_back(tmpranks);
		}
	}
	Load.close();
}

Rank::~Rank()
{
}
