#pragma once
#include "Mecro.h"
#include"MapDraw.h"


struct Rankers
{
	string m_sRank_name;
	int m_iRank_Score;
	int m_iRank_Stage;
};

class Rank 
{
protected:
	MapDraw m_DrawManager;	
	vector<Rankers*> rankers_list;
public:
	Rank();
	void Print_Rankers();	
	void Load_Rankers();	
	void Cleanup_RankList();
	~Rank();
};