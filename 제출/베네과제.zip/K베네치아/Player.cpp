#include"Player.h"

Player::Player()
{
}

void Player::For_Resetting()
{
	m_iLife = MAX_LIFE;
	m_iName = "???";
	m_LifePosition.y = HEIGHT + 1;
	m_iTotal_score = 0;
}

bool Player::Check_Gameover()
{
	if (m_iLife <= 0)
		return true;
	else
		return false;
}


void Player::DrawBaseInterface()
{

	RED
		m_DrawManager.DrawPoint("Life : ", 1, m_LifePosition.y);
	m_DrawManager.gotoxy(8, m_LifePosition.y);
	cout << "                               ";
	m_DrawManager.gotoxy(8, m_LifePosition.y);
	for (int i = 0; i < m_iLife; i++)
	{
		cout << "��";
	}
	m_DrawManager.DrawMidText("Score : ", WIDTH, m_LifePosition.y);
	cout << m_iTotal_score;
	m_DrawManager.DrawPoint("Name : ", WIDTH - 10, m_LifePosition.y);
	cout << m_iName;
	ORIGINAL
}


Player::~Player()
{
}