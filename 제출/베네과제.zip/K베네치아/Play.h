#pragma once
#include"Mecro.h"
#include"MapDraw.h"
#include"WordManager.h"
#include"Rank.h"

class Play :  public WordManager
{
private:
	Rank m_rank;
	MapDraw m_DrawManager;
	int m_iSpeed;
	int m_iMove;	
	int m_iLoad_Word;
	bool Check_Skip;
	bool Check_Storyline_Max;

public:
	Play();
	void Print_Main();
	void For_resetting();
	void Main_Before_Play();//���丮 ��ũ��
	void Playing_Game();
	void DrawSkipBox();
	void Input_Name();
	void Save_Rank();
	~Play();
};