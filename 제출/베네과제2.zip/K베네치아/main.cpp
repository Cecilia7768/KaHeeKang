#include"Play.h"

void main()
{
	system("mode con: lines=39 cols=130");
	srand(time(NULL));
	Play test;
	test.Print_Main();

}