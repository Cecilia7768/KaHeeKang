#include "MapDraw.h"


MapDraw::MapDraw()
{

}


void MapDraw::EraseWord(int n,int x,int y)
{
	gotoxy(x,y);
	for (int i = 0; i < n; i++)
	{
		cout << " ";
	}
}

void MapDraw::ErasePoint(int x, int y)
{
	gotoxy(x * 2, y);
	cout << " ";
	gotoxy(-1, -1);
	return;
}
void MapDraw::HeartDraw(int x, int y)
{
	gotoxy(x, y);
	cout << "��";
}

void MapDraw::EraseHeart(int x, int y)
{
	gotoxy(x, y);
	cout << "                       ";
}

void MapDraw::DrawPoint(string str, int x, int y)
{
	gotoxy(x * 2, y);
	cout << str;
	gotoxy(-1, -1);
	return;
}

void MapDraw::DrawMidText(string str, int x, int y)
{
	if (x > str.size() / 2)
		x -= str.size() / 2;
	gotoxy(x, y);
	cout << str;
	return;
}
void MapDraw::TextDraw(string str, int x, int y)
{
	gotoxy(x, y);
	cout << str;
}


void MapDraw::BoxErase(int Width, int Height)
{
	for (int y = 1; y < Height - 1; y++)
	{
		gotoxy(2, y);
		for (int x = 1; x < Width - 1; x++)
			cout << "  ";
	}
}

void MapDraw::BoxDraw(int Start_x, int Start_y, int Width, int Height)
{
	if (Start_x > Width)
		Start_x -= Width;
	for (int y = 0; y < Height; y++)
	{
		gotoxy(Start_x, Start_y + y);
		if (y == 0)
		{
			SKY_BLUE
				cout << "��";
			ORIGINAL
				for (int x = 1; x < Width - 1; x++)
				{
					SKY_BLUE
						cout << "��";
					ORIGINAL
				}
			SKY_BLUE
				cout << "��";
			ORIGINAL
		}
		else if (y == Height - 1)
		{
			SKY_BLUE
				cout << "��";
			ORIGINAL
				for (int x = 1; x < Width - 1; x++)
				{
					SKY_BLUE
						cout << "��";
					ORIGINAL
				}
			SKY_BLUE
				cout << "��";
			ORIGINAL
		}
		else
		{
			SKY_BLUE
				cout << "��";
			ORIGINAL
				SKY_BLUE
				for (int x = 1; x < Width - 1; x++)
				{
					cout << "  ";
				}
			ORIGINAL
			SKY_BLUE
				cout << "��";
			ORIGINAL

		}
	}
	return;
}

int MapDraw::MenuSelectCursor(int MenuLen, int AddCol, int x, int y)
{
	int Select = 1;
	RED
		DrawPoint("��", x, y);
	ORIGINAL
		while (1)
		{
			switch (getch())
			{
			case UP:
				if (Select - 1 >= 1)
				{
					ErasePoint(x, y);
					y -= AddCol;
					Select--;
				}
				break;
			case DOWN:
				if (Select + 1 <= MenuLen)
				{
					ErasePoint(x, y);
					y += AddCol;
					Select++;
				}
				break;
			case ENTER:
				return Select;
			}
			RED
				DrawPoint("��", x, y);
			ORIGINAL
		}
}
MapDraw::~MapDraw()
{
}
